const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));
// const fetch = require('node-fetch');
const WebSocket = require('ws');
const crypto = require('crypto');


// Configuration Constants
const HTTP_API_BASE_URL = 'https://nsfjqnsq5g.execute-api.us-east-1.amazonaws.com/prod';
const CLIENT_ID = generateUniqueClientId();
const NUMBER_OF_CONNECTIONS = 6; // Number of WebSocket connections to establish
const SQL_QUERY = 'SELECT * FROM job_data LIMIT 100;'; // Sample SQL query

/**
 * Generates a unique client ID.
 * The client ID is a randomly generated string of hexadecimal characters.
 *
 * @returns {string} A unique client ID.
 */
function generateUniqueClientId() {
    const clientId = crypto.randomBytes(16).toString('hex');
    return clientId;
}

/**
 * Fetches a JWT token securely from the server.
 * @returns {Promise<string>} The JWT token.
 */
async function getJwtToken() {
    try {
        const response = await fetch(`${HTTP_API_BASE_URL}/get-jwt`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ clientId: CLIENT_ID })
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(`Failed to obtain JWT: ${errorData.error}`);
        }

        const data = await response.json();
        return data.token;
    } catch (error) {
        console.error('Error fetching JWT token:', error);
        throw error;
    }
}

/**
 * Fetches the WebSocket endpoint URL from the /ws-url HTTP API.
 * @returns {Promise<string>} The WebSocket endpoint URL.
 */
async function getWebSocketUrl(jwtToken) {
    try {
        const response = await fetch(`${HTTP_API_BASE_URL}/ws-url`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${jwtToken}`
            }
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(`Failed to fetch WebSocket URL: ${errorData.error}`);
        }

        const data = await response.json();
        return data.websocket_url;
    } catch (error) {
        console.error('Error fetching WebSocket URL:', error);
        throw error;
    }
}

/**
 * Establishes a single WebSocket connection.
 */
function establishWebSocketConnection(wsUrl, connectionIndex, jwtToken) {
    return new Promise((resolve, reject) => {
        const connectionUrl = `${wsUrl}?clientId=${encodeURIComponent(CLIENT_ID)}&token=${encodeURIComponent(jwtToken)}`;
        const ws = new WebSocket(connectionUrl);

        ws.on('open', () => {
            console.log(`WebSocket connection ${connectionIndex + 1} opened`);
            resolve(ws);
        });

        ws.on('error', (error) => {
            console.error(`WebSocket connection ${connectionIndex + 1} error:`, error);
            reject(error);
        });

        ws.on('close', (code, reason) => {
            console.log(`WebSocket connection ${connectionIndex + 1} closed:`, reason);
        });
    });
}

/**
 * Establishes multiple WebSocket connections.
 */
async function establishMultipleWebSocketConnections(wsUrl, numberOfConnections, jwtToken) {
    const connections = [];

    for (let i = 0; i < numberOfConnections; i++) {
        try {
            const ws = await establishWebSocketConnection(wsUrl, i, jwtToken);
            connections.push(ws);
        } catch (error) {
            console.error(`Failed to establish WebSocket connection ${i + 1}:`, error);
        }
    }

    if (connections.length === 0) {
        throw new Error('Failed to establish any WebSocket connections');
    }

    return connections;
}

/**
 * Sends an HTTP GET request to the /data endpoint with the provided SQL query.
 */
async function sendDataRequest(sqlQuery, jwtToken) {
    try {
        const encodedQuery = encodeURIComponent(sqlQuery);
        const response = await fetch(`${HTTP_API_BASE_URL}/data?query=${encodedQuery}`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${jwtToken}`
            }
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(`Data request failed: ${errorData.error}`);
        }

        const successData = await response.json();
        console.log('Data streaming initiated:', successData.message);
    } catch (error) {
        console.error('Error sending data request:', error);
        throw error;
    }
}

/**
 * Handles incoming WebSocket messages.
 */
function handleWebSocketMessage(event, connectionIndex) {
    try {
        const message = JSON.parse(event.data);
        console.log(`Message from connection ${connectionIndex + 1}:`, message);

        if (message.type === 'completion') {
            console.log(`Data streaming complete for connection ${connectionIndex + 1}`);
        } else {
            // Handle data chunks
            // const dataChunk = message.data;
            // processDataChunk(dataChunk);
        }
    } catch (error) {
        console.error(`Error processing message from connection ${connectionIndex + 1}:`, error);
    }
}

/**
 * Sets up message handlers for all WebSocket connections.
 */
function setupWebSocketMessageHandlers(connections) {
    connections.forEach((ws, index) => {
        ws.on('message', (data) => handleWebSocketMessage({ data }, index));
    });
}

/**
 * Main function to execute the client workflow.
 */
async function main() {
    try {
        // Step 1: Obtain JWT token from the server
        const jwtToken = await getJwtToken();
        console.log('Obtained JWT token');

        // Step 2: Fetch the WebSocket endpoint URL
        const wsUrl = await getWebSocketUrl(jwtToken);
        console.log('Retrieved WebSocket URL:', wsUrl);

        // Step 3: Establish WebSocket connections
        const websocketConnections = await establishMultipleWebSocketConnections(wsUrl, NUMBER_OF_CONNECTIONS, jwtToken);
        console.log(`Established ${websocketConnections.length} WebSocket connections`);

        // Step 4: Set up message handlers
        setupWebSocketMessageHandlers(websocketConnections);

        // Step 5: Send data request
        await sendDataRequest(SQL_QUERY, jwtToken);
        console.log('HTTP GET request to /data sent successfully');
    } catch (error) {
        console.error('An error occurred in the client workflow:', error);
    }
}

// Execute the main function
main();
